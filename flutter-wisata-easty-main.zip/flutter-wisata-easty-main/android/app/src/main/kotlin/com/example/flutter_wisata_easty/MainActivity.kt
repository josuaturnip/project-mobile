package com.example.flutter_wisata_easty

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
