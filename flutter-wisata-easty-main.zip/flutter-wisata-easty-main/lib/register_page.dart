import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_wisata_easty/model/databasehelper.dart';
import 'package:flutter_wisata_easty/model/format_changer.dart';
import 'package:flutter_wisata_easty/splash_screen.dart';
import 'package:get/get.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final TextEditingController _username = TextEditingController();
  final TextEditingController _nama = TextEditingController();
  final TextEditingController _email = TextEditingController();
  final TextEditingController _phone = TextEditingController();
  final TextEditingController _dob = TextEditingController();
  final TextEditingController _password = TextEditingController();
  final TextEditingController _confirmation = TextEditingController();

  final List<String> _gender = ["Pria", "Wanita"];
  String _pilihanGender = "Pria", _judulAppbar = "Register";

  bool isEdit = false;

  @override
  void initState() {
    super.initState();
    if (Get.arguments[0] == "edit") {
      isEdit = true;
      _judulAppbar = "Update Profil";
      DataBaseHelper.getWhere("user", "username = '${Get.arguments[1]}'")
          .then((value) {
        _username.text = value[0]['username'];
        _nama.text = value[0]['name'];
        _email.text = value[0]['email'];
        _phone.text = value[0]['phone'];
        _dob.text = value[0]['dob'];
        _pilihanGender = value[0]['gender'];
      });
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_judulAppbar),
      ),
      body: Container(
        margin: const EdgeInsets.all(10),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("Username : "),
              TextField(
                controller: _username,
                enabled: !isEdit,
              ),
              const SizedBox(
                height: 5,
              ),
              const Text("Nama : "),
              TextField(
                controller: _nama,
              ),
              const SizedBox(
                height: 5,
              ),
              const Text("Email : "),
              TextField(
                controller: _email,
              ),
              const SizedBox(
                height: 5,
              ),
              const Text("Nomor Telefon : "),
              TextField(
                controller: _phone,
                keyboardType: TextInputType.number,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.digitsOnly
                ],
              ),
              const SizedBox(
                height: 5,
              ),
              const Text("Jenis Kelamin : "),
              DropdownButtonFormField(
                isExpanded: true,
                items: _gender.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _pilihanGender = value.toString();
                  });
                },
                value: _pilihanGender,
              ),
              const SizedBox(
                height: 5,
              ),
              const Text("Tanggal Lahir : "),
              TextField(
                controller: _dob,
                readOnly: true,
                onTap: () {
                  showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(1950),
                          lastDate: DateTime.now())
                      .then(
                    (value) {
                      if (value != null) {
                        _dob.text = FormatChanger().tanggalIndo(value);
                      }
                    },
                  );
                },
              ),
              const SizedBox(
                height: 5,
              ),
              Visibility(
                visible: !isEdit,
                child: const Text("Password : "),
              ),
              Visibility(
                visible: !isEdit,
                child: TextField(
                  obscureText: true,
                  controller: _password,
                ),
              ),
              Visibility(
                visible: !isEdit,
                child: const SizedBox(
                  height: 5,
                ),
              ),
              Visibility(
                visible: !isEdit,
                child: const Text("Konfirmasi : "),
              ),
              Visibility(
                visible: !isEdit,
                child: TextField(
                  obscureText: true,
                  controller: _confirmation,
                ),
              ),
              const SizedBox(
                height: 5,
              ),
              SizedBox(
                width: double.maxFinite,
                child: ElevatedButton(
                  onPressed: () {
                    if (_username.text.isEmpty ||
                        _nama.text.isEmpty ||
                        _dob.text.isEmpty) {
                      Get.snackbar("Maaf", "Harap Lengkapi Data Anda");
                    } else if (!_email.text.isEmail) {
                      Get.snackbar(
                          "Maaf", "Format Email yang anda masukkan salah");
                    } else if (_phone.text.length < 10) {
                      Get.snackbar(
                          "Maaf", "Minimal 10 digit untuk nomor telefon");
                    } else {
                      if (!isEdit) {
                        if (_password.text.length < 5) {
                          Get.snackbar("Maaf", "Password minimal 5 karakter");
                        } else if (_password.text != _confirmation.text) {
                          Get.snackbar(
                              "Maaf", "Password dan komfirmasi tidak sama");
                        } else {
                          showDialog(
                            context: context,
                            builder: (BuildContext context) => AlertDialog(
                              titlePadding: const EdgeInsets.all(0),
                              title: Container(
                                padding: const EdgeInsets.all(5),
                                color: Colors.green[900],
                                child: const Center(
                                  child: Text(
                                    "SIMPAN?",
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                              ),
                              actions: [
                                ElevatedButton(
                                  onPressed: () {
                                    Get.back();
                                  },
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.red[900]),
                                  child: const Text("BATAL"),
                                ),
                                ElevatedButton(
                                  onPressed: () {
                                    Get.back();
                                    DataBaseHelper.insert("user", {
                                      "username": _username.text,
                                      "name": _nama.text,
                                      "email": _email.text,
                                      "password": _password.text,
                                      "phone": _phone.text,
                                      "gender": _pilihanGender,
                                      "dob": _dob.text,
                                    }).then((value) {
                                      Get.offAll(() => const SplashScreen());
                                    });
                                  },
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.green[900]),
                                  child: const Text("SIMPAN"),
                                ),
                              ],
                            ),
                          );
                        }
                      } else {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) => AlertDialog(
                            titlePadding: const EdgeInsets.all(0),
                            title: Container(
                              padding: const EdgeInsets.all(5),
                              color: Colors.green[900],
                              child: const Center(
                                child: Text(
                                  "SIMPAN?",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                            actions: [
                              ElevatedButton(
                                onPressed: () {
                                  Get.back();
                                },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.red[900]),
                                child: const Text("BATAL"),
                              ),
                              ElevatedButton(
                                onPressed: () {
                                  Get.back();
                                  DataBaseHelper.update(
                                          "user",
                                          {
                                            "name": _nama.text,
                                            "email": _email.text,
                                            "phone": _phone.text,
                                            "gender": _pilihanGender,
                                            "dob": _dob.text,
                                          },
                                          "username = ?",
                                          _username.text)
                                      .then((value) {
                                    Get.offAll(() => const SplashScreen());
                                  });
                                },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.green[900]),
                                child: const Text("SIMPAN"),
                              ),
                            ],
                          ),
                        );
                      }
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green[900],
                  ),
                  child: const Text(
                    "SIMPAN",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
