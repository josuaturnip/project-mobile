import 'dart:math';

import 'package:flutter_wisata_easty/model/databasehelper.dart';

class InsertData {
  final List<String> _nama = [
    "Dufan",
    "Pantai Kuta",
    "Taman Mini Indonesia Indah",
    "Saloka Theme Park",
    "Bali Zoo",
    "Trans Studio Bandung",
    "Hillpark Sibolangit"
  ];

  final List<String> _kategori = [
    "rekreasi",
    "alam",
    "rekreasi",
    "rekreasi",
    "rekreasi",
    "rekreasi",
    "rekreasi"
  ];

  final List<String> _deskripsi = [
    "Dunia Fantasi atau yang lebih populer dengan sebutan Dufan, pertama kali dibuka untuk umum pada 29 Agustus 1985 dan merupakan theme park pertama yang dikembangkan oleh Perseroan dan telah memiliki sertifikat ISO 9001:2015 sejak Februari 2017.\n\nSelain menjadi pusat hiburan outdoor, Dufan juga merupakan kawasan edutainment fisikia terbesar di Indonesia yang memanjakan pengunjung dengan Fantasi Keliling Dunia, melalui wahana permainan berteknologi tinggi, yang terbagi dalam 9 (Sembilan) kawasan yaitu Indonesia, Jakarta, Asia, Eropa, Amerika, Yunani, Hikayat, Kalila dan Fantasy Lights.",
    "Pantai Kuta terkenal memiliki ombak yang bagus untuk olahraga selancar (surfing), terutama bagi peselancar pemula. Selain keindahan pantai, wisata pantai Kuta juga menawarkan berbagai jenis hiburan seperti bar, restoran, pertokoan, restoran, hotel, dan toko-toko kelontong, serta pedagang kaki lima di sepanjang pantai menuju Pantai Legian.",
    "Taman ini merupakan rangkuman kebudayaan bangsa Indonesia, yang mencakup berbagai aspek kehidupan sehari-hari masyarakat 33 provinsi Indonesia (pada tahun 1975) yang ditampilkan dalam anjungan daerah berarsitektur tradisional, serta menampilkan aneka busana, tarian dan tradisi daerah.\n\nDisamping itu, di tengah-tengah TMII terdapat sebuah danau yang menggambarkan miniatur kepulauan Indonesia di tengahnya, kereta gantung, berbagai museum, dan Teater IMAX Keong Mas dan Teater Tanah Airku), berbagai sarana rekreasi ini menjadikan TMIII sebagai salah satu kawasan wisata terkemuka di ibu kota.",
    "Berdiri di atas lahan seluas 12 hektar, ada 25 wahana di Saloka Theme Park Semarang yang terbagi dalam 5 zona permainan, yaitu Zona Pesisir, Zona Balalantar, Zona Segara Prada, Zona Kamayayi, dan Zona Ararya.\n\nSaat masuk ke Saloka Theme Park, kamu akan disuguhkan wahana menarik, seperti Lumbung Ilmu Galileo, Taman Galileo, dan replika Kapal Jenju di zona Pesisir.\n\nWahana Cakrawala adalah tempat favorit para pengunjung. Dari kincir raksasa warna-warni setinggi 33 meter, kamu dapat menikmati pemandangan indah zona-zona permainan di Saloka Theme Park dan deretan pegunungan di Jawa Tengah.\n\nDengan satu tiket masuk Saloka Theme Park Semarang, kamu juga bisa memasuki wahana Adu Nyali yang merupakan rumah hantu dengan memberikan sensasi permainan yang menegangkan. Selain itu, masih banyak wahana yang menarik untuk dicoba, mulai dari wahana Kupu-Kupu hingga Senggal - Senggol.",
    "Jalan-jalan ke tempat wisata di Bali tidak harus selalu ke pantai. Kamu juga bisa berkunjung ke Bali Zoo yang spektakuler untuk melihat kumpulan satwa Indonesia yang menakjubkan! Berlokasi di desa Singapadu, Bali Zoo yang rindang dipenuhi dengan pepohonan tropis, memiliki lebih dari 500 satwa termasuk satwa langka seperti Gajah Sumatera, Orangutan, Harimau Benggala, Binturong, dan Singa Afrika. Para pengunjung dapat berinteraksi secara langsung dengan satwa-satwa jinak yang terlatih dan jangan lewatkan kesempatan untuk berfoto bersama satwa langka ini! Ada juga wahana di Bali Zoo yang tak kalah menyenangkan, yaitu Night Safari. Jangan lewatkan aktivitas unik yang satu ini, ya!",
    "Bandung Trans Studio bisa jadi pilihan yang tepat untuk kamu yang memiliki sejumlah wahana asyik yang cocok untuk semua usia. Berlokasi di Jalan Gatot Subroto, ini merupakan pusat perbelanjaan terbesar di Kota Bandung. Objek wisata ini dilengkapi dengan berbagai permainan yang cocok untuk si kecil hingga yang memacu adrenalin.\n\nUntuk para remaja atau dewasa muda, Trans Studio Bandung memiliki banyak titik foto menarik yang akan membuat pengalaman belanjamu semakin seru. Selain itu, terdapat bioskop TSM XXI yang dilengkapi berbagai film nasional maupun internasional terbaru.\n\nBukan hanya itu saja, Trans Studio Bandung disebut sebagai salah satu taman hiburan indoor terbesar di dunia dengan total 20 wahana yang dibagi menjadi 3 tema berbeda.\n\nKamu tak perlu khawatir dengan biaya masuk Trans Studio Bandung. Karena dengan harga tiket masuk Trans Studio Bandung yang terjangkau, kamu bisa menikmati wahana Dunia Lain, Jelajah, Super Heroes 4D, dan masih banyak lagi!",
    "Ayo ajak keluarga Anda untuk menikmati hiburan di Hillpark Sibolangit! Berlokasi sekitar 1 jam perjalanan dari Medan, Hillpark Sibolangit menawarkan keseruan berbagai wahana atraksi yang terbagi dalam 3 zona dengan fitur dan tema yang unik: The Heritage, The Lost City, dan Cartoon Town. Hillpark Sibolangit merupakan amusement park terbesar di Sumatra."
  ];

  void inputData() {
    for (int i = 0; i < _nama.length; i++) {
      DataBaseHelper.insert("wahana", {
        "nama": _nama[i],
        "harga": (Random().nextInt(30) + 15) * 1000,
        "kategori": _kategori[i],
        "kapasitas": Random().nextInt(20000) + 15000,
        "deskripsi": _deskripsi[i],
        "image": "${_nama[i]}.jpg",
      });
    }
  }
}
