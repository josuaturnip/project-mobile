import 'package:flutter/material.dart';
import 'package:flutter_wisata_easty/model/databasehelper.dart';
import 'package:flutter_wisata_easty/model/datasharedpreferences.dart';
import 'package:flutter_wisata_easty/register_page.dart';
import 'package:flutter_wisata_easty/splash_screen.dart';
import 'package:get/get.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final TextEditingController _passwordold = TextEditingController();
  final TextEditingController _passwordnew = TextEditingController();
  final TextEditingController _confirmation = TextEditingController();

  String _username = "",
      _nama = "",
      _password = "",
      _email = "",
      _phone = "",
      _gender = "",
      _dob = "";

  @override
  void initState() {
    super.initState();
    DataSharedPreferences().readString("username").then((value) {
      _username = value!;
      DataBaseHelper.getWhere("user", "username = '$_username'").then((value) {
        _nama = value[0]['name'];
        _password = value[0]['password'];
        _email = value[0]['email'];
        _phone = value[0]['phone'];
        _gender = value[0]['gender'];
        _dob = value[0]['dob'];
      });
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.all(10),
            child: const Text(
              "Akun Saya",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 25,
              ),
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Row(
            children: [
              Flexible(
                flex: 1,
                child: SizedBox(
                  width: 100,
                  height: 100,
                  child: Image.asset('assets/app_logo.png'),
                ),
              ),
              Flexible(
                flex: 3,
                child: SizedBox(
                  height: 100,
                  width: double.maxFinite,
                  child: Card(
                    color: Colors.green,
                    child: Container(
                      padding: const EdgeInsets.all(5),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            "Info Profil",
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Table(
                            defaultVerticalAlignment:
                                TableCellVerticalAlignment.middle,
                            columnWidths: const <int, TableColumnWidth>{
                              0: FractionColumnWidth(0.3),
                              1: FractionColumnWidth(0.05),
                              2: FractionColumnWidth(0.65),
                            },
                            children: [
                              TableRow(
                                children: [
                                  const Text(
                                    "username",
                                    style: TextStyle(color: Colors.white),
                                  ),
                                  const Text(
                                    ":",
                                    style: TextStyle(color: Colors.white),
                                  ),
                                  Text(
                                    _username,
                                    textAlign: TextAlign.end,
                                    style: const TextStyle(color: Colors.white),
                                  ),
                                ],
                              ),
                              TableRow(
                                children: [
                                  const Text(
                                    "nama",
                                    style: TextStyle(color: Colors.white),
                                  ),
                                  const Text(
                                    ":",
                                    style: TextStyle(color: Colors.white),
                                  ),
                                  Text(
                                    _nama,
                                    textAlign: TextAlign.end,
                                    style: const TextStyle(color: Colors.white),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
          const SizedBox(
            height: 10,
          ),
          Card(
            color: Colors.green,
            child: Container(
              padding: const EdgeInsets.all(5),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    "Data Pribadi",
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Table(
                    defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                    columnWidths: const <int, TableColumnWidth>{
                      0: FractionColumnWidth(0.3),
                      1: FractionColumnWidth(0.05),
                      2: FractionColumnWidth(0.65),
                    },
                    children: [
                      TableRow(
                        children: [
                          const Text(
                            "Email",
                            style: TextStyle(color: Colors.white),
                          ),
                          const Text(
                            ":",
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            _email,
                            textAlign: TextAlign.end,
                            style: const TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                      TableRow(
                        children: [
                          const Text(
                            "Phone",
                            style: TextStyle(color: Colors.white),
                          ),
                          const Text(
                            ":",
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            _phone,
                            textAlign: TextAlign.end,
                            style: const TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                      TableRow(
                        children: [
                          const Text(
                            "Gender",
                            style: TextStyle(color: Colors.white),
                          ),
                          const Text(
                            ":",
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            _gender,
                            textAlign: TextAlign.end,
                            style: const TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                      TableRow(
                        children: [
                          const Text(
                            "Tanggal Lahir",
                            style: TextStyle(color: Colors.white),
                          ),
                          const Text(
                            ":",
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            _dob,
                            textAlign: TextAlign.end,
                            style: const TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(
                    width: double.maxFinite,
                    child: ElevatedButton(
                      onPressed: () {
                        Get.to(() => const RegisterPage(),
                            arguments: ["edit", _username]);
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.grey[300]),
                      child: const Text(
                        "EDIT PROFIL",
                        style: TextStyle(
                            color: Colors.black, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: double.maxFinite,
                    child: ElevatedButton(
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) => AlertDialog(
                            titlePadding: const EdgeInsets.all(0),
                            title: Container(
                              padding: const EdgeInsets.all(5),
                              color: Colors.green[900],
                              child: const Center(
                                child: Text(
                                  "UPDATE PASSWORD",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                            content: SingleChildScrollView(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text("Password Lama : "),
                                  TextField(
                                    obscureText: true,
                                    controller: _passwordold,
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  const Text("Password Baru : "),
                                  TextField(
                                    obscureText: true,
                                    controller: _passwordnew,
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  const Text("Konfirmasi : "),
                                  TextField(
                                    obscureText: true,
                                    controller: _confirmation,
                                  ),
                                ],
                              ),
                            ),
                            actions: [
                              ElevatedButton(
                                onPressed: () {
                                  Get.back();
                                },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.grey),
                                child: const Text("BATAL"),
                              ),
                              ElevatedButton(
                                onPressed: () {
                                  if (_passwordold.text != _password) {
                                    Get.snackbar(
                                        "Maaf", "Password Lama Anda Salah");
                                  } else if (_passwordnew.text.length < 5) {
                                    Get.arguments("Maaf",
                                        "Karakter Password kurang dari 5");
                                  } else if (_passwordnew.text !=
                                      _confirmation.text) {
                                    Get.arguments("Maaf",
                                        "Password dan kombinasi tidak sama");
                                  } else {
                                    DataBaseHelper.update(
                                        "user",
                                        {"password": _passwordnew.text},
                                        "username=?",
                                        _username);
                                    _password = _passwordnew.text;
                                    _passwordold.text = "";
                                    _passwordnew.text = "";
                                    _confirmation.text = "";
                                    setState(() {});
                                    Get.back();
                                    Get.snackbar("Berhasil",
                                        "Password Anda Berhasil diganti");
                                  }
                                },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.red[900]),
                                child: const Text("SIMPAN"),
                              ),
                            ],
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue[900]),
                      child: const Text(
                        "GANTI PASSWORD",
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
          Container(
            width: double.maxFinite,
            margin: const EdgeInsets.only(left: 5, right: 5),
            child: ElevatedButton(
              onPressed: () {
                showDialog(
                    context: context,
                    builder: (BuildContext context) => AlertDialog(
                          titlePadding: const EdgeInsets.all(0),
                          title: Container(
                            padding: const EdgeInsets.all(5),
                            color: Colors.red[900],
                            child: const Center(
                              child: Text(
                                "LOGOUT?",
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ),
                          actions: [
                            ElevatedButton(
                              onPressed: () {
                                Get.back();
                              },
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.grey),
                              child: const Text("BATAL"),
                            ),
                            ElevatedButton(
                              onPressed: () {
                                Get.back();
                                DataSharedPreferences().clearData();
                                Get.offAll(() => const SplashScreen());
                              },
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.red[900]),
                              child: const Text("YA"),
                            ),
                          ],
                        ));
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red[900]),
              child: const Text(
                "LOGOUT",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
