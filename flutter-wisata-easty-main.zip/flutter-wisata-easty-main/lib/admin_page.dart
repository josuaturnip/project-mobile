import 'package:flutter/material.dart';
import 'package:flutter_wisata_easty/model/databasehelper.dart';
import 'package:flutter_wisata_easty/splash_screen.dart';
import 'package:get/get.dart';

class AdminPage extends StatefulWidget {
  const AdminPage({super.key});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  List<Widget> _list = [];

  bool _isAnyList = false;

  @override
  void initState() {
    super.initState();
    getData();
  }

  void getData() {
    _list = [];
    DataBaseHelper.customQuery("""SELECT A.*, B.image 
            FROM transaksi AS A 
            JOIN wahana AS B 
            ON A.id_wisata = B.id 
            WHERE A.is_approved = 0""").then((value) {
      if (value.isEmpty) {
        _isAnyList = false;
      } else {
        for (int i = 0; i < value.length; i++) {
          _list.add(
            InkWell(
              onTap: () {
                showDialog(
                    context: context,
                    builder: (BuildContext context) => AlertDialog(
                          titlePadding: const EdgeInsets.all(0),
                          title: Container(
                            padding: const EdgeInsets.all(5),
                            color: Colors.green[900],
                            child: const Center(
                              child: Text(
                                "Menu",
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ),
                          actions: [
                            ElevatedButton(
                              onPressed: () {
                                Get.back();
                              },
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.grey),
                              child: const Text("Tutup"),
                            ),
                            ElevatedButton(
                              onPressed: () {
                                DataBaseHelper.update(
                                    "transaksi",
                                    {"is_approved": 1},
                                    "id=?",
                                    "${value[i]['id']}");
                                getData();
                                Get.back();
                              },
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.green[900]),
                              child: const Text("Approve"),
                            ),
                          ],
                        ));
              },
              child: Card(
                color: value[i]['is_approved'] == 0
                    ? Colors.red[900]
                    : Colors.green[900],
                child: Column(
                  children: [
                    SizedBox(
                      height: 200,
                      width: double.maxFinite,
                      child: Image.asset(
                        "assets/${value[i]['image']}".toLowerCase(),
                        fit: BoxFit.fill,
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Text(
                      "Pemesan : ${value[i]['username']}",
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.white),
                    ),
                    Text(
                      "${value[i]['tiket']} Tiket diPesan",
                      style: const TextStyle(color: Colors.white),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                  ],
                ),
              ),
            ),
          );
        }
        _isAnyList = true;
      }
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Daftar Tiket"),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            onPressed: () {
              Get.offAll(() => const SplashScreen());
            },
            icon: const Icon(Icons.power_settings_new),
          ),
        ],
      ),
      body: Container(
        margin: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _isAnyList
                ? Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        children: _list,
                      ),
                    ),
                  )
                : const Expanded(
                    child: Center(
                      child: Text("Tidak ada riwayat Pembelian"),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}
