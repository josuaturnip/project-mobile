import 'package:flutter/material.dart';
import 'package:flutter_wisata_easty/model/databasehelper.dart';
import 'package:flutter_wisata_easty/model/datasharedpreferences.dart';
import 'package:get/get.dart';

class PemesananPage extends StatefulWidget {
  const PemesananPage({super.key});

  @override
  State<PemesananPage> createState() => _PemesananPageState();
}

class _PemesananPageState extends State<PemesananPage> {
  List<Widget> _daftar = [];
  bool _isAnyHistory = false;

  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        margin: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Riwayat Pembelian",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 25,
              ),
            ),
            _isAnyHistory
                ? Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        children: _daftar,
                      ),
                    ),
                  )
                : const Expanded(
                    child: Center(
                      child: Text("Tidak ada riwayat Pembelian"),
                    ),
                  ),
          ],
        ),
      ),
    );
  }

  void getData() {
    _daftar = [];
    DataSharedPreferences().readString("username").then((value) {
      DataBaseHelper.customQuery(
              """SELECT B.id AS idtrans, A.id, A.nama, A.image, B.tiket, B.is_approved 
              FROM wahana AS A 
              JOIN transaksi AS B ON A.id = B.id_wisata 
              WHERE B.username = '$value'""")
          .then((value) {
        if (value.isNotEmpty) {
          _isAnyHistory = true;
          for (int i = 0; i < value.length; i++) {
            _daftar.add(
              InkWell(
                onTap: () {
                  showDialog(
                      context: context,
                      builder: (BuildContext context) => AlertDialog(
                            titlePadding: const EdgeInsets.all(0),
                            title: Container(
                              padding: const EdgeInsets.all(5),
                              color: Colors.green[900],
                              child: const Center(
                                child: Text(
                                  "Menu",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                            actions: [
                              ElevatedButton(
                                onPressed: () {
                                  Get.back();
                                },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.grey),
                                child: const Text("Tutup"),
                              ),
                              ElevatedButton(
                                onPressed: () {
                                  DataBaseHelper.deleteWhere("transaksi",
                                      "id=?", "${value[i]['idtrans']}");
                                  Get.back();
                                  getData();
                                },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.red[900]),
                                child: const Text("Hapus"),
                              ),
                            ],
                          ));
                },
                child: Card(
                  color: value[i]['is_approved'] == 0
                      ? Colors.red[900]
                      : Colors.green[900],
                  child: Column(
                    children: [
                      SizedBox(
                        height: 200,
                        width: double.maxFinite,
                        child: Image.asset(
                          "assets/${value[i]['image']}".toLowerCase(),
                          fit: BoxFit.fill,
                        ),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Text(
                        "${value[i]['nama']}",
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                      Text(
                        "${value[i]['tiket']} Tiket diPesan",
                        style: const TextStyle(color: Colors.white),
                      ),
                      Text(
                        value[i]['is_approved'] == 0
                            ? "Tiket Belum diverifikasi"
                            : "Tiket Telah Terverifikasi",
                        style: const TextStyle(color: Colors.white),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                    ],
                  ),
                ),
              ),
            );
          }
        } else {
          _isAnyHistory = false;
        }
        setState(() {});
      });
    });
  }
}
