import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_wisata_easty/dashboard_page.dart';
import 'package:flutter_wisata_easty/model/databasehelper.dart';
import 'package:flutter_wisata_easty/model/datasharedpreferences.dart';
import 'package:flutter_wisata_easty/model/format_changer.dart';
import 'package:get/get.dart';

class PaymentPage extends StatefulWidget {
  const PaymentPage({super.key});

  @override
  State<PaymentPage> createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  String _username = "",
      _nama = "",
      _image = "assets/prambanan.png",
      _metode = "-";
  int _id = 0, _harga = 0, _tiket = 0;

  final _tanggal = DateTime.now();

  @override
  void initState() {
    super.initState();
    DataSharedPreferences().readString("username").then((value) {
      _username = value!;
    });
    _id = Get.arguments[0];
    _nama = Get.arguments[1];
    _harga = Get.arguments[2];
    _image = Get.arguments[3];
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Pembayaran"),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 200,
              width: double.maxFinite,
              child: Image.asset(
                _image,
                fit: BoxFit.fitWidth,
              ),
            ),
            Container(
              width: double.maxFinite,
              padding: const EdgeInsets.all(10),
              color: Colors.green[900],
              child: Center(
                child: Column(
                  children: [
                    Text(
                      _nama.toUpperCase(),
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 25,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      "Harga Satuan : $_harga",
                      style: const TextStyle(color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              width: double.maxFinite,
              height: double.maxFinite,
              margin: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        "Total Harga : Rp. ${_tiket * _harga},-",
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Expanded(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            ElevatedButton(
                                onPressed: () {
                                  setState(() {
                                    if (_tiket > 0) {
                                      _tiket--;
                                    }
                                  });
                                },
                                child: const Text("-")),
                            Container(
                              margin:
                                  const EdgeInsets.only(left: 20, right: 20),
                              child: Text(
                                _tiket.toString(),
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 25),
                              ),
                            ),
                            ElevatedButton(
                                onPressed: () {
                                  setState(() {
                                    _tiket++;
                                  });
                                },
                                child: const Text("+"))
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    "Metode Pembayaran : $_metode",
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Center(
                    child: ElevatedButton(
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) => AlertDialog(
                            contentPadding: const EdgeInsets.all(5),
                            content: SizedBox(
                              height: 400,
                              child: SingleChildScrollView(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      margin: const EdgeInsets.all(10),
                                      child: const Text(
                                        "Dompet Digital",
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: double.maxFinite,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          setState(() {
                                            _metode = "GoPay";
                                          });
                                          Get.back();
                                        },
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.blue[200]),
                                        child: const Text(
                                          "GoPay",
                                          style: TextStyle(color: Colors.black),
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: double.maxFinite,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          setState(() {
                                            _metode = "Dana";
                                          });
                                          Get.back();
                                        },
                                        child: const Text("Dana"),
                                      ),
                                    ),
                                    SizedBox(
                                      width: double.maxFinite,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          setState(() {
                                            _metode = "ShopeePay";
                                          });
                                          Get.back();
                                        },
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.orange),
                                        child: const Text("ShopeePay"),
                                      ),
                                    ),
                                    SizedBox(
                                      width: double.maxFinite,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          setState(() {
                                            _metode = "OVO";
                                          });
                                          Get.back();
                                        },
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.purple),
                                        child: const Text("OVO"),
                                      ),
                                    ),
                                    SizedBox(
                                      width: double.maxFinite,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          setState(() {
                                            _metode = "Link Aja";
                                          });
                                          Get.back();
                                        },
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.red),
                                        child: const Text("Link Aja"),
                                      ),
                                    ),
                                    SizedBox(
                                      width: double.maxFinite,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          setState(() {
                                            _metode = "Flip";
                                          });
                                          Get.back();
                                        },
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor:
                                                Colors.orange[300]),
                                        child: const Text("Flip"),
                                      ),
                                    ),
                                    Container(
                                      margin: const EdgeInsets.all(10),
                                      child: const Text(
                                        "M-Bangking",
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: double.maxFinite,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          setState(() {
                                            _metode = "Bank BRI";
                                          });
                                          Get.back();
                                        },
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.blue[700]),
                                        child: const Text("Bank BRI"),
                                      ),
                                    ),
                                    SizedBox(
                                      width: double.maxFinite,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          setState(() {
                                            _metode = "Bank BNI";
                                          });
                                          Get.back();
                                        },
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.green[700]),
                                        child: const Text("Bank BNI"),
                                      ),
                                    ),
                                    SizedBox(
                                      width: double.maxFinite,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          setState(() {
                                            _metode = "Bank Mandiri";
                                          });
                                          Get.back();
                                        },
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.blue[900]),
                                        child: const Text("Bank Mandiri"),
                                      ),
                                    ),
                                    SizedBox(
                                      width: double.maxFinite,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          setState(() {
                                            _metode = "Bank BCA";
                                          });
                                          Get.back();
                                        },
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.blue[600]),
                                        child: const Text("Bank BCA"),
                                      ),
                                    ),
                                    SizedBox(
                                      width: double.maxFinite,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          setState(() {
                                            _metode = "Bank Danamon";
                                          });
                                          Get.back();
                                        },
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.orange),
                                        child: const Text("Bank Danamon"),
                                      ),
                                    ),
                                    SizedBox(
                                      width: double.maxFinite,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          setState(() {
                                            _metode = "Maybank";
                                          });
                                          Get.back();
                                        },
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.yellow),
                                        child: const Text(
                                          "Maybank",
                                          style: TextStyle(color: Colors.black),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green[900]),
                      child: const Text("Pilih Metode Pembayaran"),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          if (_tiket == 0) {
            Get.snackbar("Maaf", "Anda belum memesan Tiket");
          } else if (_metode == "-") {
            Get.snackbar("Maaf", "Anda Belum Memilih Metode Pembayaran");
          } else {
            showDialog(
              context: context,
              builder: (BuildContext context) => AlertDialog(
                titlePadding: const EdgeInsets.all(0),
                title: Container(
                  padding: const EdgeInsets.all(5),
                  color: Colors.green[900],
                  child: const Center(
                    child: Text(
                      "LAKUKAN PEMBAYARAN",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
                contentPadding: const EdgeInsets.all(5),
                content: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text("Segera Lakukan Pembayaran Sebelum : "),
                    Card(
                      child: Container(
                        width: double.maxFinite,
                        color: Colors.grey,
                        height: 100,
                        child: Center(
                          child: Text(
                            FormatChanger().tanggalIndoFromString(
                                "${_tanggal.add(const Duration(days: 1))}"),
                            style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 40,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    const Text("Transfer Pembayaran ini ke nomor rekening : "),
                    const Center(
                      child: Text(
                        "081122334455",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 30),
                      ),
                    ),
                    const Text("Total Tagihan"),
                    Center(
                      child: Text(
                        "Rp. ${(_harga * _tiket) + Random().nextInt(999) + 1},-",
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 30),
                      ),
                    ),
                    Center(
                      child: Text(
                        "Lakukan pembayaran hingga 3 digit terakhir sebagai validasi pembayaran",
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 12, color: Colors.red[900]),
                      ),
                    ),
                  ],
                ),
                actions: [
                  ElevatedButton(
                    onPressed: () {
                      Get.back();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red[900],
                    ),
                    child: const Text("BATAL"),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      DataBaseHelper.insert("transaksi", {
                        "username": _username,
                        "id_wisata": _id,
                        "tiket": _tiket,
                        "is_approved": 0
                      });
                      Get.offAll(() => const DashboardPage());
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green[900],
                    ),
                    child: const Text("BAYAR"),
                  ),
                ],
              ),
            );
          }
        },
        backgroundColor: Colors.green[900],
        child: const Icon(Icons.shopping_bag_outlined),
      ),
    );
  }
}
