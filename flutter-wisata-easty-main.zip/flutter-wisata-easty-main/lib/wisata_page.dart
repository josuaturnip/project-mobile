import 'package:flutter/material.dart';
import 'package:flutter_wisata_easty/detail_wisata_page.dart';
import 'package:flutter_wisata_easty/model/databasehelper.dart';
import 'package:get/get.dart';

class WisataPage extends StatefulWidget {
  const WisataPage({super.key});

  @override
  State<WisataPage> createState() => _WisataPageState();
}

class _WisataPageState extends State<WisataPage> {
  final List<Widget> _daftar = [];

  @override
  void initState() {
    super.initState();
    DataBaseHelper.getWhere("wahana", "kategori = '${Get.arguments}'")
        .then((value) {
      for (int i = 0; i < value.length; i++) {
        _daftar.add(InkWell(
          onTap: () {
            Get.to(() => const DetailWisataPage(), arguments: value[i]);
          },
          child: Card(
            color: Colors.green[900],
            child: Column(
              children: [
                SizedBox(
                  height: 200,
                  width: double.maxFinite,
                  child: Image.asset(
                    "assets/${value[i]['image']}".toLowerCase(),
                    fit: BoxFit.fill,
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                Text(
                  "${value[i]['nama']}",
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, color: Colors.white),
                ),
                Text(
                  "Rp. ${value[i]['harga']} / orang",
                  style: const TextStyle(color: Colors.white),
                ),
                const SizedBox(
                  height: 5,
                ),
              ],
            ),
          ),
        ));
      }
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Daftar Wahana"),
      ),
      body: Container(
        padding: const EdgeInsets.all(10),
        child: SingleChildScrollView(
          child: Column(
            children: _daftar,
          ),
        ),
      ),
    );
  }
}
