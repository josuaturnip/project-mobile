import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_wisata_easty/admin_page.dart';
import 'package:flutter_wisata_easty/dashboard_page.dart';
import 'package:flutter_wisata_easty/model/databasehelper.dart';
import 'package:flutter_wisata_easty/model/datasharedpreferences.dart';
import 'package:flutter_wisata_easty/model/insert_data.dart';
import 'package:flutter_wisata_easty/register_page.dart';
import 'package:get/get.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  final TextEditingController _username = TextEditingController();
  final TextEditingController _password = TextEditingController();

  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    DataBaseHelper.getAll("wahana").then((value) {
      if (value.isEmpty) {
        InsertData().inputData();
      }
    });
    Future.delayed(const Duration(seconds: 2)).then((value) {
      DataSharedPreferences().checkData("username").then((value) {
        if (value) {
          Get.offAll(() => const DashboardPage());
        } else {
          setState(() {
            isLoading = false;
          });
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 200,
                height: 200,
                child: Image.asset('assets/app_logo.png'),
              ),
              const Text(
                "Travel App",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
              ),
              const SizedBox(
                height: 50,
              ),
              isLoading
                  ? const SizedBox(
                      width: 300,
                      child: LinearProgressIndicator(
                        color: Colors.green,
                      ),
                    )
                  : SizedBox(
                      width: 300,
                      child: Column(
                        children: [
                          TextField(
                            controller: _username,
                            decoration: InputDecoration(
                              prefixIcon: const Icon(Icons.person),
                              labelText: "username",
                              prefixStyle: const TextStyle(
                                  color: Color(0xFF000080),
                                  fontWeight: FontWeight.w600),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          TextField(
                            controller: _password,
                            obscureText: true,
                            decoration: InputDecoration(
                              prefixIcon: const Icon(Icons.vpn_key),
                              labelText: "password",
                              prefixStyle: const TextStyle(
                                  color: Color(0xFF000080),
                                  fontWeight: FontWeight.w600),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: double.maxFinite,
                            child: ElevatedButton(
                              onPressed: () {
                                if (_username.text.isEmpty ||
                                    _password.text.isEmpty) {
                                  Get.snackbar(
                                    "Maaf",
                                    "Harap Lengkapi data Anda",
                                  );
                                } else if (_username.text == "admin" &&
                                    _password.text == "admin") {
                                  Get.to(() => const AdminPage());
                                } else {
                                  DataBaseHelper.getWhere("user",
                                          "username = '${_username.text}' AND password = '${_password.text}'")
                                      .then((value) {
                                    if (value.isEmpty) {
                                      Get.snackbar(
                                          "Maaf", "User Tidak DiTemukan",
                                          backgroundColor: Colors.red,
                                          colorText: Colors.white);
                                    } else {
                                      DataSharedPreferences().saveString(
                                          "username", _username.text);
                                      Get.offAll(() => const DashboardPage());
                                    }
                                  });
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green[900],
                              ),
                              child: const Text("LOGIN"),
                            ),
                          ),
                          const SizedBox(
                            height: 25,
                          ),
                          RichText(
                            text: TextSpan(
                              text: 'Belum Punya Akun?',
                              style: const TextStyle(color: Colors.black),
                              children: <TextSpan>[
                                TextSpan(
                                  text: ' Daftar!',
                                  recognizer: TapGestureRecognizer()
                                    ..onTap = () {
                                      Get.to(() => const RegisterPage(),
                                          arguments: ["register", ""]);
                                    },
                                  style: TextStyle(
                                    color: Colors.green[900],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
