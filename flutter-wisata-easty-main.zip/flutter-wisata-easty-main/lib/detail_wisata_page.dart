import 'package:flutter/material.dart';
import 'package:flutter_wisata_easty/payment_page.dart';
import 'package:get/get.dart';

class DetailWisataPage extends StatefulWidget {
  const DetailWisataPage({super.key});

  @override
  State<DetailWisataPage> createState() => _DetailWisataPageState();
}

class _DetailWisataPageState extends State<DetailWisataPage> {
  int _id = 0;
  String _image = "assets/prambanan.png",
      _nama = "nama",
      _kategori = "kategori",
      _kapasitas = "kapasitas",
      _deskripsi = "deskripsi";

  int _harga = 0;

  @override
  void initState() {
    super.initState();
    _id = Get.arguments['id'];
    _nama = Get.arguments['nama'];
    _image = "assets/${Get.arguments['image']}".toLowerCase();
    _harga = Get.arguments['harga'];
    _kategori = Get.arguments['kategori'];
    _kapasitas = Get.arguments['kapasitas'];
    _deskripsi = Get.arguments['deskripsi'];
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Detail Wisata"),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 200,
              width: double.maxFinite,
              child: Image.asset(
                _image,
                fit: BoxFit.fitWidth,
              ),
            ),
            Container(
              width: double.maxFinite,
              padding: const EdgeInsets.all(10),
              color: Colors.green[900],
              child: Center(
                child: Text(
                  _nama.toUpperCase(),
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 25,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            Container(
              width: double.maxFinite,
              margin: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Harga Tiket Masuk : Rp. $_harga / Orang"),
                  Text("Kategori Wisata : ${_kategori.toUpperCase()}"),
                  Text("Kapasitas : $_kapasitas orang"),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    "Deskripsi : ",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(
                    _deskripsi,
                    textAlign: TextAlign.justify,
                  ),
                  const SizedBox(
                    height: 100,
                  )
                ],
              ),
            )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green[900],
        onPressed: () {
          Get.to(() => const PaymentPage(),
              arguments: [_id, _nama, _harga, _image]);
        },
        child: const Icon(Icons.shopping_bag_outlined),
      ),
    );
  }
}
